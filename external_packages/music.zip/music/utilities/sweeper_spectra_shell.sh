#!/usr/bin/env bash

./sweeper_spectra.sh spectra_and_vn
mv spectra_and_vn results

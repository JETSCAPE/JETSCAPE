#ifndef _SRC_MUSIC_LOGO_H_
#define _SRC_MUSIC_LOGO_H_

namespace MUSIC_LOGO {
    void display_logo(int selector);
    void display_code_description_and_copyright();
    void welcome_message();
}

#endif  // _SRC_MUSIC_LOGO_H_
